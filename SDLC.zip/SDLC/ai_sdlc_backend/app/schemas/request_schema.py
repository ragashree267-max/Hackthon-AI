from pydantic import BaseModel

class GenerateRequest(BaseModel):
    doc_type: str
    description: str
