from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas.request_schema import GenerateRequest
from app.models.database import SessionLocal, GeneratedDocument, Base, engine
from app.services.ai_service import generate_document

from fastapi import APIRouter
from langchain_openai import ChatOpenAI

router = APIRouter()

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/generate")
def generate_ai_doc(request: GenerateRequest, db: Session = Depends(get_db)):
    output = generate_document(request.doc_type, request.description)
    
    new_doc = GeneratedDocument(
        doc_type=request.doc_type,
        input_prompt=request.description,
        output_text=output
    )
    db.add(new_doc)
    db.commit()
    db.refresh(new_doc)
    
    return {"status": "success", "document": new_doc.output_text}

router = APIRouter()

@router.get("/test_ai")
async def test_ai():
    try:
        model = ChatOpenAI(model="azure/genailab-maas-gpt-4o-mini")
        return {"message": "LangChain OpenAI loaded successfully!"}
    except Exception as e:
        return {"error": str(e)}

