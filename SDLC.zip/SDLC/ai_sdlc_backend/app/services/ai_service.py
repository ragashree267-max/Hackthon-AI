from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from app.utils.config import OPENAI_API_KEY
import os 
import httpx 
client = httpx.Client(verify=False)

def generate_document(doc_type: str, description: str):
    """Uses LangChain to generate SDLC document sections."""

    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model = "azure/genailab-maas-gpt-4o-mini",
        api_key="sk-oD-aQUkGRTodnnqDdk7oSQ",
        http_client = client
)
        # model="gpt-4o-mini"  # you can switch to gpt-3.5-turbo or gpt-4-turbo
    

    template = """
    You are an expert software analyst. Generate a high-quality {doc_type}
    document for a software system described as follows:

    Description: {description}

    Return the output in a professional format suitable for submission.
    """
    
    prompt = PromptTemplate(
        template=template,
        input_variables=["doc_type", "description"]
    )

    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run({"doc_type": doc_type, "description": description})


# app/services/ai_service.py
# from langchain_openai import ChatOpenAI
# from langchain.schema import HumanMessage
# import os 
# import httpx 
# client = httpx.Client(verify=False)

# async def generate_document(prompt: str):
#     """
#     Classifies items into A/B/C categories based on quantity and unit cost.
#     Example prompt: "Item: Laptop, Quantity: 10, Unit Cost: 1000"
#     """
#     # model = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.2)
#     llm = ChatOpenAI(
#          base_url="https://genailab.tcs.in",
#          model = "azure/genailab-maas-gpt-4o-mini",
#          api_key="sk-oD-aQUkGRTodnnqDdk7oSQ",
#          http_client = client
#  )

#     system_prompt = """
#     You are an AI assistant that performs ABC classification for inventory items.
#     Rules:
#     - A: High value, low quantity (tight control, frequent review)
#     - B: Moderate value and quantity (regular monitoring)
#     - C: Low value, high quantity (minimal oversight)

#     Input format: list of items with name, quantity, and unit cost.
#     Output: JSON with categories A/B/C.
#     """

#     full_prompt = f"{system_prompt}\n\n{prompt}"
#     response = model([HumanMessage(content=full_prompt)])
#     return response.content


