# # from fastapi import FastAPI
# # from app.routes import ai_agent

# # app = FastAPI(title="AI for SDLC - Backend", version="1.0")

# # app.include_router(ai_agent.router, prefix="/api/ai", tags=["AI Agent"])

# # @app.get("/")
# # def root():
# #     return {"message": "AI-Powered SDLC Assistant is running!"}

# # from fastapi import FastAPI
# # from app.routes import ai_agent

# # app = FastAPI()

# # app.include_router(ai_agent.router, prefix="/api")

# # @app.get("/")
# # def root():
# #     return {"message": "AI-Powered SDLC Assistant is running!"}

# from fastapi import FastAPI
# from pydantic import BaseModel
# from langchain_openai import ChatOpenAI

# app = FastAPI()

# # Health check endpoint
# @app.get("/")
# def read_root():
#     return {"message": "AI-Powered SDLC Assistant is running!"}

# # Request body model
# class PromptRequest(BaseModel):
#     prompt: str

# # POST endpoint
# @app.post("/ai/generate")
# def generate_text(request: PromptRequest):
#     model = ChatOpenAI(model="gpt-3.5-turbo")
#     response = model.invoke(request.prompt)
#     return {"content": response}


from fastapi import FastAPI
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from fastapi.middleware.cors import CORSMiddleware
import os 
import httpx 
client = httpx.Client(verify=False)

app = FastAPI()

# Allow frontend (HTML/JS) to call backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can restrict to ["http://127.0.0.1:5500"] if needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check endpoint
@app.get("/")
def read_root():
    return {"message": "AI-Powered SDLC Assistant is running!"}


# Step 1: Create request body model
class PromptRequest(BaseModel):
    prompt: str


# Step 2: Define POST endpoint
@app.post("/ai/generate")
def generate_text(request: PromptRequest):
    try:
        # model = ChatOpenAI(model="gpt-3.5-turbo")
        llm = ChatOpenAI(
            base_url="https://genailab.tcs.in",
            model = "azure/genailab-maas-gpt-4o-mini",
            api_key="sk-oD-aQUkGRTodnnqDdk7oSQ",
            http_client = client
)
        # response = model.invoke(request.prompt)
        # return {"content": response.content}
        response = llm.invoke(request.prompt)
        return {"content": response.content}
    except Exception as e:
        return {"error": str(e)}